<?php

// These values are specified for project 5.
$database = 'albumdb';
$user = 'albumdb_user';
$password = 'albumdb_password';
$server = 'localhost';

//  Code to process XMLHttpRequest requests from JavaScript.
if (count($_REQUEST)==0) {  
    // No parameters, so this is the first XMLHttpRequest,
	// ...to get release years from the database.
	
    // Opens the database.
	$connOne = openDatabase($server, $database, $user, $password);
	
	// String containing the SQL command.
	$sqlString = 'SELECT ReleaseYear FROM albums;';
	$yearObjects = $connOne->query($sqlString);  // Query the database.
	// Foreach loop to create an array of years from the query results.
	foreach ($yearObjects as $album) {
		$yearsArray[] = $album["ReleaseYear"];
	}
	$yrs = array_unique($yearsArray);  // Array containing only unique release years, i.e. no duplicate years.
	sort($yrs);  // Sort the array of unique years.
	sendToBrowser($yrs);  // Encodes the array in JSON and echoes it.
	
} else {  
    // There is a parameter, so this is the second XMLHttpRequest,
	// ...to get Title and Artist for rows matching the provided year.
	
	$param = json_decode($_REQUEST["data"]);  // Decodes the JSON-formatted parameter.
	$requestedYear = $param->year;            // Extracts the year value from the parameter.
	$connTwo = openDatabase($server, $database, $user, $password);  // Open the database.
	// String containing the SQL command.  NOTE: It is imperative to use the DOT for concatenation in php!!
	$sqlStringTwo = 'SELECT Title,Artist FROM albums WHERE ReleaseYear = ' . $requestedYear;
	
	$nameObjects = $connTwo->query($sqlStringTwo);  // Query the database.
	
	$albumTitleNames = mysqli_fetch_all($nameObjects, MYSQLI_ASSOC);  // The array of results.
	sendToBrowser($albumTitleNames);  // Encodes the query result in JSON and echoes it.
	
}


/* Function to open a MySQL database.
 *   Parameter: $svrname -- string containing server name
 *   Parameter: $dbname -- string containing database name
 *   Parameter: $username -- string containing user name
 *   Parameter: $password -- string containing password
 *   Returns: PDO object to use for subsequent database access.  Null if failure.
 */
function openDatabase($svrname, $dbname, $username, $password) {
   $conn = new mysqli($svrname, $username, $password, $dbname);
// Check connection
	if ($conn->connect_error) {
		echo "connection failed: " . $conn->connect_error;
		die("Connection failed: " . $conn->connect_error);
	} 
	return $conn;
}


/* Function to encode parameter in JSON and echo to browser.
 *   Parameter: $data -- The data to be transmitted.  Object or array.
 */
function sendToBrowser($data) {
	// This function is complete.  Not much going on here.
    echo json_encode($data);
}

?>