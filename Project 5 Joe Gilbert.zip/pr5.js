 var url = "http://localhost:8080/pr5.php";

 /*  Function to request list of sorted and unique years.  Similar to
     Project 4.  Should work as provided, assuming PHP returns array of years.
  */
 $(document).ready(function() {
	var request = new XMLHttpRequest();
	request.open("GET", url, true);
	request.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
	request.onreadystatechange = function() {
		if (this.readyState == 4 && this.status == 200) {
			//alert(request.responseText);
			var years = JSON.parse(request.responseText);
			var select = document.getElementById("years");
            select.innerHTML = "";
            for (var i = 0; i < years.length; i++) {
                   option = document.createElement("option");
				   text = document.createTextNode(years[i]);
                   option.appendChild(text);
                   select.appendChild(option);
			}
		} else {
			//alert("Http Request failed.");
		}
	}
	request.send(null);
	
// Event handler function.  Called when a year is selected from the drop-down list. 
  	document.getElementById("years").onchange = function() {
	    // Get the selected year from drop-down list.
		var yearSelection = document.getElementById("years");
		var aYearWeWant = yearSelection.options[yearSelection.selectedIndex].innerHTML;
		// The string that is sent to the php file as the parameter.
        var parameter = 'data={ "year":' + aYearWeWant + '}'; 
		var request = new XMLHttpRequest();
		request.open("POST",url, true);
		request.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
		request.onload = function() {
			if (this.readyState == 4 && this.status == 200) {
				
				
				// Apply JSON.parse to response.  Result should be an array of objects,
				// each element which has .Title and .Artist.
				// Then create the LI element and add to the list.
				// This should be similar to Project 4.  
				
				// yearInfo is the array of objects with each object having a Title and Artist attribute.
				var yearInfo = JSON.parse(request.responseText);
				// ol is the Ordered List in the HTML file.
				var ol = document.getElementById("albumList");
				ol.innerHTML = "";
				
				
				for (var i = 0; i < yearInfo.length; i++) {
					
					li = document.createElement("li");  // Create a list element.
					em = document.createElement("em");  // Create an emphasis element.
					textOne = document.createTextNode(yearInfo[i].Title);  // Text node holding the Title.
					textTwo = document.createTextNode(", " + yearInfo[i].Artist);  // Text node holding the Artist.
					em.appendChild(textOne);      // Append the Title to the emphasis element. 
					li.appendChild(em);           // Append the now emphasized Title to the list element.
					li.appendChild(textTwo);      // Append the Artist to the list element.
					ol.appendChild(li);           // Append the list element to the ordered list.
					
					
					
				}
			} else {
				//alert("Http Request failed.");
			}
		}
		request.send(parameter);

    };
});