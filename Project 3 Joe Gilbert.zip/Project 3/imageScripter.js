
var morn0, morn1, morn2, even0, even1, even2, imgArray;

function Image(src, alt, desc) {
	this.src = src;
	this.alt = alt;
	this.desc = desc;
}

morn0 = new Image("images/midnight.png", "Midnight", "It is midnight.");
morn1 = new Image("images/earlyMorn.png", "Dawn", "It is early in the morning.");
morn2 = new Image("images/lateMorn.png", "Morning", "It is late in the morning.");
even0 = new Image("images/noon.png", "Noon", "It is noon.");
even1 = new Image("images/afterNoon.png", "Afternoon", "It is early in the evening.");
even2 = new Image("images/earlyNight.png", "Night", "It is late at night.");

imgArray = [morn0, morn1, morn2, even0, even1, even2];


function imgChooser() {
	var hourOne, hour, theDays, today, tiny, theDate, 
	theMonth, monthArray, hourMinute;
	
	hourOne = new Date();
	hour = hourOne.getHours();
	
	theDays = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", 
	"Friday", "Saturday"];
	
	monthArray = ["January", "February", "March", "April", "May", "June", "July", 
	"August", "September", "October", "November", "December"];
	
	today = hourOne.getDay();
	theDate = hourOne.getDate();
	theMonth = hourOne.getMonth();
	
	
	if (hour <= 1) {
		tiny = imgArray[0];
	} else if (hour > 1 && hour < 7) {
		tiny = imgArray[1];
	} else if (hour >= 7 && hour < 12) {
		tiny = imgArray[2];
	} else if (hour >= 12 && hour < 13) {
		tiny = imgArray[3];
	} else if (hour >= 13 && hour < 18) {
		tiny = imgArray[4];
	} else {
		tiny = imgArray[5];
	}
	hourMinute = hourOne.toLocaleTimeString();
	
	document.getElementById("myImage").src = tiny.src;
	document.getElementById("myImage").alt = tiny.alt;
	document.getElementById("aCaption").innerHTML = tiny.desc;
	
	document.getElementById("myHotDate").innerHTML = "It\'s currently " + 
	hourMinute.replace(/:\d+ /, ' ') + " on this interesting " + 
	theDays[today] + ", " + monthArray[theMonth] + " " + theDate + ".";
	
}



function clockWatcher() {
	setInterval(imgChooser, 60000);
	imgChooser();
	
	document.getElementById("slImage").src = imgArray[0].src;
	document.getElementById("slImage").alt = imgArray[0].alt;
	document.getElementById("bCaption").innerHTML = imgArray[0].desc; 
}
var imgCount = 0;
function getRandPic() {
	imgCount = Math.round(Math.random() * 5);
	document.getElementById("slImage").src = imgArray[imgCount].src;
	document.getElementById("slImage").alt = imgArray[imgCount].alt;
	document.getElementById("bCaption").innerHTML = imgArray[imgCount].desc;   
}


function nextPic() {
	
	
	if (imgCount == 5) {	
		imgCount = 0;
	} else {
		imgCount = imgCount + 1;	
	}
	document.getElementById("slImage").src = imgArray[imgCount].src;
	document.getElementById("slImage").alt = imgArray[imgCount].alt;
	document.getElementById("bCaption").innerHTML = imgArray[imgCount].desc;		
}









