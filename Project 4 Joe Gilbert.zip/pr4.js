
window.onload = function() {
   document.getElementById("yearList").style.visibility = "hidden";
   document.getElementById("releaseYears").onchange = listMatchingAlbums;
   getJSONdata();
}

var albums = new Array();
var yearList = new Array();

function getJSONdata() {  
   var url = "albums/albums_short.json";
   var request = new XMLHttpRequest();
   request.open("GET", url);
   
   // Define a variable named "request" to hold an XMLHttpRequest object.
   // Call the open function on the XMLHttpRequest object to initialize it.
	
   // Define an event handler for the server's response.
   request.onload = function() {
      if (request.readyState == 4 && request.status == 200) {
		 albums = JSON.parse(request.responseText);
		 
		 document.getElementById("collectionSize").innerHTML = albums.length;
		 /* for (var i = 0; i < albums.length; i++) {
			 
		 } */
		 // Parse the response into a variable called "albums"
         // Use the length attribute of the albums array to populate 
		 // the number of albums displayed in the HTML file.
		 // (Hint:  use document.getElementId and innerHTML)
      } else {
         alert("Http Request failed.");		
      }
      buildYearList();
      displayYearList();
   }

   // The send() function should be the last thing done within this function.  
   request.send(null);
}

// Build list of unique release years. 
function buildYearList() {
	/* For each ReleaseYear in the albums array, use the Array.indexOf() function to check to see if
	that year is already in the yearList JavaScript array.  If not, push it into the yearList array.
	When finished, sort the yearList array.   */
	for (var i = 0; i < albums.length; i++) {
		
		if (yearList.indexOf(albums[i].ReleaseYear) == -1) {
			yearList.push(albums[i].ReleaseYear);
			
		}
		
	}
	yearList.sort();
}

function displayYearList() {  
	// It builds the list of unique release years.
   var option;
   var text;
   
   for (var i = 0; i < yearList.length; i++) {
	   
	   option = document.createElement("option");
	   text = document.createTextNode(yearList[i].toString());
	   option.appendChild(text);
	   document.getElementById("releaseYears").appendChild(option);
	   // Create an "option" element
	   // Create a text node that contains the year.  document.createTextNode function will do this.
	   // Append the text node as a child to the option element.
	   // Append the option element to the <select> list.  (Hint:  use getElementById).
	   
   }
}

function listMatchingAlbums() {
   var index = document.getElementById("releaseYears").selectedIndex;
   var year = yearList[index];  // Get the selected year from the selected entry. 
   var table = document.getElementById("yearList");  // Reinitialize the list of albums for a selected year
   table.style.visibility = "visible";
   table.innerHTML = "<tr> <th>Title</th> <th>Artists</th> </tr>";
   
   /* Search the array of albums.  If an album release year matches the selected year,
		add the album title and artist to the ordered list.  */
   for (var i = 0; i < albums.length; i++) {
	   var albDat = albums[i];
	   if (albDat.ReleaseYear == year) {
		   var alTitle = albDat.Title;
		   var artist = albDat.Artist;
		   //var alTxt = "Title: " + alTitle + " Artist: " + artist; 
		   //li = "<li type='circle' value='" + alTxt + "'>";
		   //li += alTxt + "</li>";
		   //ol.innerHTML += li; 
		   
		   var alTxt = "<td>" + alTitle + "</td>" + " " + "<td>" + artist + "</td>";
		   
		   tr = "<tr> ";
		   tr += alTxt + " </tr>";
		   
		   table.innerHTML += tr;
	   }
	   
	   
	  /* If a particular album release year matches the selected year:
			1) create an "li" element
			2) create a textNode that contains the album title and artist
			3) append the textNode as a child to the "li" element
			4) append the "li" element as a child to the "ol" element  */
      
   }
}